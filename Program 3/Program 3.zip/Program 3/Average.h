

class Average{
	public:
		double getAverage(int num1, int num2){
			return ((num1 + num2) / 2);
		}
		double getAverage(int num1, int num2, int num3){
			return ((num1 + num2 + num3) / 3);
		}
		double getAverage(double num1, double num2){
			return ((num1 + num2) / 2);
		}
		double getAverage(double num1, double num2, double num3){
			return ((num1 + num2 + num3) / 3);
		}
};
