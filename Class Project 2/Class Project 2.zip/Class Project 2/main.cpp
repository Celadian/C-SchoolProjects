#include <iostream>
#include "Car.h"



using namespace std;

int main(int argc, char** argv) {
	Car car;
	string carName = "";
	
	cout << "Please type the name of the car: ";
	cin >> carName;
	car.setName(carName);
	
	cout << "\n" << car.getName() << " is entered as the car's name.";
	
	

	
	return 0;
}




